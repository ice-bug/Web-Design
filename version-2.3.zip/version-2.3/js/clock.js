var Clock,date,hrs,min,sec;

function cloky(){
    date = new Date();
    hrs = date.getHours();
    min = date.getMinutes();
    sec = date.getSeconds();

    if(hrs <= 9){
        hrs = "0" + hrs;
    }
    if(min <= 9){
        min = "0" + min;
    }
    if(sec <= 9){
        sec = "0" + sec;
    }
    Clock = hrs + ":" + min + ":" + sec;
    document.getElementById("clock").innerHTML =Clock;
    setTimeout(cloky,1000);
}
cloky();