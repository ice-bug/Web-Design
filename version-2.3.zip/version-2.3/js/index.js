const Preloader = document.getElementById("overlay");
var Loading = false;
var Load = false;
setTimeout(function(){
    Loading = true;
    if(Load==true){
        Preloader.style.display = "none";
    }
},2000);
var users=null;
window.addEventListener('load',function(){
    Load = true;
    if(Loading){
        Preloader.style.display = "none";  
    }
    users = JSON.parse(localStorage.getItem("users"));
    if(!users){
        users = [];
    }
});

/*Hamburger working*/

const Hamburger = document.getElementById("hamburger");
const closeside = document.getElementById("navClose");
const Navbar = document.getElementById('navbar');
const Content = document.getElementById("content");

Hamburger.addEventListener('click',function(){
    Navbar.style.width = "250px";
    Content.style.marginLeft = "250px";
});
closeside.addEventListener('click',function(){
    Navbar.style.width = "0px";
    Content.style.marginLeft = "0px";
});

/*Hamburger working end*/

/*modal working*/

const Modal = document.getElementById("modal");
const Login = document.getElementById('login');
const ModalClose = document.getElementById("modalclose");

Login.addEventListener('click',function(){
    Modal.style.display = "block";
    Navbar.style.width = "0px";
    Content.style.marginLeft = "0px";
});
ModalClose.addEventListener('click',function(){
    Modal.style.display = "none";
});

/*form verification*/

Submit.addEventListener("click",function(){
    var Submit = document.getElementById("submit");
    var Email = document.getElementById("email").value;
    var Password = document.getElementById("password").value;
    var userObj ={email:Email,pass:Password}
    users.push(userObj);
    var store = JSON.stringify(users);
    function Login(u){
        if(u.email.length>10 && u.pass.length>8){
            // swal("Good job!", "You clicked the button!", "success");
            localStorage.setItem("users",store);
        }else if(u.email.length<10){
            // swal("OOPS!", "Something is wrong!", "warning");
        }else if(u.pass.length<8){
            // swal("OOPS!", "Something is wrong!", "warning");
        }
    }
    Login(userObj); 
    document.getElementById("email").value = "";
    document.getElementById("password").value = "";
});
    




